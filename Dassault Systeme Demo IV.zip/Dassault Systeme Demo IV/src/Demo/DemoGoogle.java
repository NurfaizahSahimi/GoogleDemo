package Demo;
import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


import org.openqa.selenium.TakesScreenshot;
public class DemoGoogle {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\aizpa\\node_modules\\chromedriver\\lib\\chromedriver\\chromedriver_1.exe"); 
	    WebDriver driver=new ChromeDriver();
	    driver.manage().window().maximize();
	    //launch
        driver.get("https://www.google.com/");
        Thread.sleep(3000);

        //search keys
        driver.findElement(By.xpath("html/body/div[1]/div[3]/form/div[1]/div[1]/div[1]/div/div[2]/input")).sendKeys(String.valueOf("Dassault System"));
        driver.findElement(By.xpath("html/body/div[1]/div[3]/form/div[1]/div[1]/div[1]/div/div[2]/input")).sendKeys(Keys.ENTER);
        
        // click on second result 
        driver.findElement(By.xpath("//*[@id=\"rso\"]/div[3]/div/div/div/div[1]/a")).click();
        Thread.sleep(3000);
        
        // take screenshot of the link open
        File src= ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        try {
            FileUtils.copyFile(src, new File("Capture"));
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        // close browser
        driver.quit();  
	}

}
